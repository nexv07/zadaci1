﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace listasort
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //start
            timer1.Start();
            label1.Text = "0";
            listBox1.Items.Clear();
            Random x = new Random();
            for(int i= 0;i<4;i++)
            {
                int sluc = x.Next(1, 100);
                listBox1.Items.Add(Convert.ToString(sluc));
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //gore
            int tren = listBox1.SelectedIndex;
            if (tren > 0)
            {
                int pret = tren - 1;
                string temp = listBox1.Items[pret].ToString();
                listBox1.Items[pret] = listBox1.Items[tren];
                listBox1.Items[tren] = temp;
                listBox1.SelectedIndex = pret;
            }
            button4.PerformClick();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //provera
            int k = listBox1.Items.Count;
            Boolean tacno = true;
            for(int i = 0; i < k-1; i++)
            {
                int prvi = Convert.ToInt32(listBox1.Items[i]);
                int drugi = Convert.ToInt32(listBox1.Items[i+1]);
                if (drugi < prvi) tacno = false;
            }
            if (tacno == true)
            {
                MessageBox.Show("BRAVO");
                MessageBox.Show(label1.Text);
                timer1.Stop();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //dole
            int tren = listBox1.SelectedIndex;
            if (tren <= 10)
            {
                int pret = tren + 1;
                string temp = listBox1.Items[pret].ToString();
                listBox1.Items[pret] = listBox1.Items[tren];
                listBox1.Items[tren] = temp;
                listBox1.SelectedIndex = pret;
            }
            button4.PerformClick();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            int poeni = Convert.ToInt32(label1.Text);
            poeni++;
            (label1.Text) = Convert.ToString(poeni);
        }
    }
}
