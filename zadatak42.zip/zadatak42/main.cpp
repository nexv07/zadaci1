#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
using namespace std;
int dx[] = {-1, 1, 0, 0};
int dy[] = {0, 0, -1, 1};

int mozeli(int niz[10][10],int x, int y){
for (int i = 0; i < 4; i++) {
        int nx = x + dx[i];
        int ny = y + dy[i];
        if (niz[nx][ny] != 1) {
            return 0;
        }
    }
    return 1;
}
int main()
{
    srand(time(0));
    int niz[10][10],loka,lokb;
    for(int i=0;i<10;i++){
        for(int j=0;j<10;j++){
            niz[i][j]=rand()%2;
        }
    }
    //ispisivanje niza bez promena
    for(int i=0;i<10;i++){
        for(int j=0;j<10;j++){
            printf(" %d",niz[i][j]);
        }
        printf("\n");
    }
    //unosenje 2 na rand poz
    do{
        loka=rand()%10;
        lokb=rand()%10;
    }while(niz[loka][lokb]!=0);
    niz[loka][lokb]=2;

    //unosenje 3 na rand poz
    do{
        loka=rand()%10;
        lokb=rand()%10;
    }while(niz[loka][lokb]!=0);
    niz[loka][lokb]=3;
    //razmak izmedju nizova
    printf("\n\n\n");
    printf("\nNiz sa 2 i 3\n");
    //ispisivanje niza sa promenama
    for(int i=0;i<10;i++){
        for(int j=0;j<10;j++){
            printf(" %d",niz[i][j]);
        }
        printf("\n");
    }
    return 0;
}
