﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prodavnica
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        //vodi na alat
        private void button1_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(1);
        }

        //loadovanje forme
        private void Form1_Load(object sender, EventArgs e)
        {
            tabControl1.Appearance = TabAppearance.FlatButtons;
            tabControl1.ItemSize = new Size(0, 1);
            tabControl1.SizeMode = TabSizeMode.Fixed;

            textBox1.ReadOnly = true;
            textBox2.ReadOnly = true;
            textBox6.ReadOnly = true;
            textBox5.ReadOnly = true;
            textBox7.ReadOnly = true;
            timer1.Start();
        }
        //vodi na namirnice
        private void button2_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(2);
            
        }
        //nazad dugme
        private void nazad_Click(object sender, EventArgs e)
        {
            tabControl1.SelectTab(0);
        }

        //alat 
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int x = listBox1.SelectedIndex;
            string nazivalat = listBox1.Items[x].ToString();
            textBox1.Text = nazivalat;

            string cena = listBox2.Items[x].ToString();
            textBox2.Text = cena;

        }

        //ok za alat
        private void ok_alat(object sender, EventArgs e)
        {
            if (textBox3.Text == "")
            {
                string x = "1";
                listBox5.Items.Add(textBox1.Text);
                listBox6.Items.Add(textBox2.Text);
                listBox7.Items.Add(x);
                int temp = Convert.ToUInt16(textBox2.Text);
                string temp2 = Convert.ToString(temp);
                listBox8.Items.Add(temp2);
            }
            else
            {
                listBox5.Items.Add(textBox1.Text);
                listBox6.Items.Add(textBox2.Text);
                listBox7.Items.Add(textBox3.Text);
                int temp = Convert.ToUInt16(textBox2.Text);
                int temp1 = Convert.ToUInt16(textBox3.Text);
                int temp3 = temp * temp1;
                string temp2 = Convert.ToString(temp3);
                listBox8.Items.Add(temp2);
            }
            


            tabControl1.SelectTab(3);
        }

        //racunazbir
        private void racunazbir(object sender, EventArgs e)
        {
            int suma = 0;
            foreach (var x in listBox8.Items)
            {
                int vrednost;
                if (int.TryParse(x.ToString(), out vrednost))
                {
                    suma += vrednost;
                }
                string zbir = suma.ToString();
                textBox7.Text = zbir;

            }
        }

        //namirnice
        private void listBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            int x = listBox1.SelectedIndex;
            string nazivalat = listBox1.Items[x].ToString();
            textBox1.Text = nazivalat;

            string cena = listBox2.Items[x].ToString();
            textBox2.Text = cena;
        }

        //brisi dugme
        private void brisi_Click(object sender, EventArgs e)
        {
            listBox5.Items.Clear();
            listBox6.Items.Clear();
            listBox7.Items.Clear();
            listBox8.Items.Clear();
            textBox7.Text = "";
        }

        //plati dugme
        private void plati_Click(object sender, EventArgs e)
        {
            listBox5.Items.Clear();
            listBox6.Items.Clear();
            listBox7.Items.Clear();
            listBox8.Items.Clear();
            textBox7.Text = "";
            MessageBox.Show("Platili ste");
        }
    }
}
