namespace spaceinvaders
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        int pom = 7;
        int pom1 = 3;
        int pravac = 555;

        //nebitno
        private void label2_Click(object sender, EventArgs e)
        {

        }
        //start
        private void button1_Click(object sender, EventArgs e)
        {
            button2.Enabled = true;
            timer1.Start();
            button2.Focus();
            timer3.Start();
            button4.Top = 55;
            button5.Top = 55;
            button6.Top = 55;
            button4.Left = 74;
            button5.Left = 236;
            button6.Left = 430;
            button3.Left = 11430;
            button2.Left = 236;
            button2.Top = 371;
            label2.Text = "0";

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (pravac == 0) button2.Left += pom;
            if (pravac == 2) button2.Left -= pom;
            //padanje
            button4.Top += pom1;
            button5.Top += pom1;
            button6.Top += pom1;
            //pogadjanje
            Random x = new Random();
            int poeni = Convert.ToInt32(label2.Text);
            if (button3.Bounds.IntersectsWith(button4.Bounds))
            {
                button4.Top = 55;
                button4.Left = x.Next(430);
                poeni++;
            }
            if (button3.Bounds.IntersectsWith(button5.Bounds))
            {
                button5.Top = 55;
                button5.Left = x.Next(430);
                poeni++;
            }
            if (button3.Bounds.IntersectsWith(button6.Bounds))
            {
                button6.Top = 55;
                button6.Left = x.Next(430);
                poeni++;
            }
            
            //propadanje
            if (button4.Top > 410)
            {
                button4.Top = 55;
                button4.Left = x.Next(430);
                poeni--;
            }
            if (button5.Top > 410)
            {
                button5.Top = 55;
                button5.Left = x.Next(430);
                poeni--;
            }
            if (button6.Top > 410)
            {
                button6.Top = 55;
                button6.Left = x.Next(430);
                poeni--;
            }
            label2.Text = Convert.ToString(poeni);
        }

        //kretanje i sudaranje
        private void button2_KeyPress(object sender, KeyPressEventArgs e)
        {
            //kretanje
            if (e.KeyChar == 'a') pravac = 2;
            if (e.KeyChar == 'd') pravac = 0;
            if (e.KeyChar == ' ')
            {
                button3.Left = button2.Left + 20;
                button3.Top = button2.Top + 20;
                timer2.Start();
            }
            //sudranje
            if (button2.Bounds.IntersectsWith(button4.Bounds))
            {
                button2.Enabled = false;
                MessageBox.Show("GAME OVER");
                timer1.Stop();
                timer2.Stop();
                timer3.Stop();
            }
            if (button2.Bounds.IntersectsWith(button5.Bounds))
            {
                button2.Enabled = false;
                MessageBox.Show("GAME OVER");
                timer1.Stop();
                timer2.Stop();
                timer3.Stop();
            }
            if (button2.Bounds.IntersectsWith(button6.Bounds))
            {
                button2.Enabled = false;
                MessageBox.Show("GAME OVER");
                timer1.Stop();
                timer2.Stop();
                timer3.Stop();
            }
            //border
            if (button2.Left < -10)
            {
                button2.Left = 565;
            }
            if (button2.Left > 565)
            {
                button2.Left = -10;
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            button3.Top -= 15;
        }






        //mozda ne treba
        private void timer3_Tick(object sender, EventArgs e)
        {
            
        }
    }
}
