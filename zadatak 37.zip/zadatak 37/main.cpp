#include <iostream>
#include <stdio.h>
#include <stdlib.h>
using namespace std;

class pravougaonik{
private:
    float duzina,sirina;
public :
    void set(float a, float b){
    duzina = a;
    sirina = b;

    }
    float get(){
    float x = 2 * duzina + 2 * sirina;
    return x;

    }

};


int main()
{
    pravougaonik oblik;
    float e,f;
    printf("Unesi duzinu\n");
    scanf("%f",&e);
    printf("Unesi sirinu\n");
    scanf("%f",&f);
    oblik.set(e,f);
    printf("Obim je %10.2f",oblik.get());
    return 0;
}
