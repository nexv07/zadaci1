using System.Numerics;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double zbir = 0;
            int i = listView1.Items.Count;
            i++;

            string s1 = Convert.ToString(i);
            string s2 = textBox1.Text;
            string s3 = textBox2.Text;
            string s4 = textBox3.Text;
    
            string[] zapis = { s1, s2, s3, s4 };
            var red = new ListViewItem(zapis);
            listView1.Items.Add(red);
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {


        }

        private void button4_Click(object sender, EventArgs e)
        {
            int i = listView1.SelectedIndices[0];
            listView1.Items[i].SubItems[1].Text = textBox1.Text;
            listView1.Items[i].SubItems[2].Text = textBox2.Text;
            listView1.Items[i].SubItems[3].Text = textBox3.Text;
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            button7.PerformClick();

        }

        private void button3_Click(object sender, EventArgs e)
        {

            int i = listView1.SelectedIndices[0];
            listView1.Items.RemoveAt(i);
            button6.PerformClick();
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
            button7.PerformClick();


        }

        private void button2_Click(object sender, EventArgs e)
        {
            listView1.Items.Clear();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            int br = listView1.Items.Count;
            int id = 1;
            for (int i = 0; i < br; i++)
            {

                listView1.Items[i].SubItems[0].Text = Convert.ToString(id);
                id++;
            }
        }

        private void listView1_Click(object sender, EventArgs e)
        {

            int i = listView1.SelectedIndices[0];
            textBox1.Text = listView1.Items[i].SubItems[1].Text;
            textBox2.Text = listView1.Items[i].SubItems[2].Text;
            textBox3.Text = listView1.Items[i].SubItems[3].Text;
        }

        private void button7_Click(object sender, EventArgs e)
        {
         int max=listView1.Items.Count;
            double zbir = 0;
            for(int i = 0;i < max;i++)
            {
                double br1=Convert.ToDouble(listView1.Items[i].SubItems[2].Text);
                double br2 = Convert.ToDouble(listView1.Items[i].SubItems[3].Text);

                zbir += br1 * br2;
            }
            label2.Text= zbir.ToString();   
        }
    }
}
