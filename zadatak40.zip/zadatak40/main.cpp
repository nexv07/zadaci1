#include <stdio.h>

int main() {
    int n, k;
    int ukupnoKanapa = 0;
    int duzina, zbirDuzina = 0;


    printf("Unesite broj kanapa (n): ");
    scanf("%d", &n);
    printf("Unesite duzinu jednog kanapa (k): ");
    scanf("%d", &k);


    printf("Unesite duzine kanapa:\n");
    for (int i = 0; i < n; i++) {
        printf("Unesite duzinu kanapa %d: ", i + 1);
        scanf("%d", &duzina);

        zbirDuzina += duzina;
        ukupnoKanapa += duzina / k;
        if (duzina % k != 0) {
            ukupnoKanapa++;
        }
    }


    if (zbirDuzina < k) {
        ukupnoKanapa = 0;
    }

    if (zbirDuzina >= k && ukupnoKanapa == 0) {
        ukupnoKanapa = 1;
    }

    printf("Ukupno potrosenih celih kanapa: %d\n", ukupnoKanapa);

    return 0;
}
