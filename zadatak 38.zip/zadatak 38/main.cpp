#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#define PI 3.14
using namespace std;

class lopta{
private:
    int r;
public :
    void set(int a){
    r = a;

    }
    int get(){
    int zapremina = ((r*r*r)*4/3)*PI;
    return zapremina;

    }

};


int main()
{
    lopta niz[10];

    int p,mini=100000;
    srand(time(0));
    int i=0;
    for(i=0;i<10;i++){
        p = rand()%100+1;
        niz[i].set(p);
        printf("%d\n",niz[i].get());


    }
    for(i=0;i<10;i++){
        if(niz[i].get()<mini){
                mini=niz[i].get();

        }


        }

    printf("najmanji %d",mini);

    return 0;
}
