﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _8x8tabla
{
    public partial class Form1 : Form
    {
        //1 predstavlja crvenog a 2 zelenog
        int[,] niz = {
        {0,0,0,0,0,0,0,0 },
        {0,0,0,0,0,0,0,0 },
        {0,0,0,0,0,0,0,0 },
        {0,0,0,0,0,0,0,0 },
        {0,0,0,0,0,0,0,0 },
        {0,0,0,0,0,0,0,0 },
        {0,0,0,0,0,0,0,0 },
        {0,0,0,0,0,0,0,0 }
        };
        

        
        int selektovano_dugme;
        int button_count = 0;
        bool red = true;
        //staviti false ako zelis da ti igras
        bool robot_igra = true;
        //crveni je true a zeleni false
        bool zeleni_pobeda = false;
        bool crveni_pobeda = false;
        int i, j;

        public Form1()
        {
            InitializeComponent();
            sakriva();
            timer1.Start();
            timer2.Start();
        }

        //igra
        private void Dugme_Click(object sender, EventArgs e)
        {
            Button dugmence = sender as Button;
            if (dugmence == null)
                return;
            var koordinata = dugmence.Tag as Tuple<int, int>;
            if (koordinata != null)
            {
                    i = koordinata.Item1;
                    j = koordinata.Item2;
            }
            //crveni
            if (red == true)
            {              
                dugmence.BackColor = System.Drawing.Color.FromName("Red");
                dugmence.Enabled = false;
                red = false;
                button_count++;
                niz[i,j] = 1;
                if (robot_igra == false)
                    robot_igra = true;
                else
                    robot_igra = false;
            }
            //zeleni
            else
            {
                dugmence.BackColor = System.Drawing.Color.FromName("Green");
                dugmence.Enabled = false;
                red = true;
                button_count++;
                niz[i,j] = 2;
                if (robot_igra == false)
                    robot_igra = true;
                else
                    robot_igra = false;
            }
        }
        //sakriji
        void sakriva()
        {
            for(int i = 9; i < 65; i++)
            {
                Button dugme = this.Controls.Find("button" + i, true).FirstOrDefault() as Button;

                if (dugme != null)
                {
                   // dugme.Enabled = false;  //ugasi dugme
                    //dugme.Visible = false;  // Sakrij dugme
                }
            }

        }


        //proverava da li je red popunjen
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (button_count == 8)
            {
                for (int i = 9; i < 17; i++)
                {
                    Button dugme = this.Controls.Find("button" + i, true).FirstOrDefault() as Button;

                    if (dugme != null)
                    {
                        dugme.Enabled = true;  //pokreni dugme
                        dugme.Visible = true;  // Sakrij dugme
                    }
                }
            }

            if (button_count == 16)
            {
                for (int i = 17; i < 25; i++)
                {
                    Button dugme = this.Controls.Find("button" + i, true).FirstOrDefault() as Button;

                    if (dugme != null)
                    {
                        dugme.Enabled = true;  //pokreni dugme
                        dugme.Visible = true;  // Sakrij dugme
                    }
                }
            }
            if (button_count == 24)
            {
                for (int i = 25; i < 33; i++)
                {
                    Button dugme = this.Controls.Find("button" + i, true).FirstOrDefault() as Button;

                    if (dugme != null)
                    {
                        dugme.Enabled = true;  //pokreni dugme
                        dugme.Visible = true;  // Sakrij dugme
                    }
                }
            }
            if (button_count == 32)
            {
                for (int i = 33; i < 41; i++)
                {
                    Button dugme = this.Controls.Find("button" + i, true).FirstOrDefault() as Button;

                    if (dugme != null)
                    {
                        dugme.Enabled = true;  //pokreni dugme
                        dugme.Visible = true;  // Sakrij dugme
                    }
                }
            }
            if (button_count == 40)
            {
                for (int i = 41; i < 49; i++)
                {
                    Button dugme = this.Controls.Find("button" + i, true).FirstOrDefault() as Button;

                    if (dugme != null)
                    {
                        dugme.Enabled = true;  //pokreni dugme
                        dugme.Visible = true;  // Sakrij dugme
                    }
                }
            }
            if (button_count == 48)
            {
                for (int i = 49; i < 57; i++)
                {
                    Button dugme = this.Controls.Find("button" + i, true).FirstOrDefault() as Button;

                    if (dugme != null)
                    {
                        dugme.Enabled = true;  //pokreni dugme
                        dugme.Visible = true;  // Sakrij dugme
                    }
                }
            }
            if (button_count == 56)
            {
                for (int i = 57; i < 65; i++)
                {
                    Button dugme = this.Controls.Find("button" + i, true).FirstOrDefault() as Button;

                    if (dugme != null)
                    {
                        dugme.Enabled = true;  //pokreni dugme
                        dugme.Visible = true;  // Sakrij dugme
                    }
                }
            }
        }











        //Robot igra
        private void timer2_Tick(object sender, EventArgs e)
        {
            if (robot_igra == true)
            {
                if (button_count < 8)
                {
                    Random x = new Random();
                    int y = x.Next(1, 9);
                    Button dugme = this.Controls.Find("button" + y, true).FirstOrDefault() as Button;
                    if (dugme.Enabled == false)
                    {
                        while(dugme.Enabled == false)
                        {
                            y = x.Next(1, 9);
                            dugme = this.Controls.Find("button" + y, true).FirstOrDefault() as Button;
                        }
                    }
                    else
                    {
                        dugme.PerformClick();
                        robot_igra = false;
                    }                  
                }

                if (button_count >= 8&& button_count<17)
                {
                    for(int i = 9; i < 17; i++)
                    {
                        Random x = new Random();
                        int y = x.Next(9, 17);
                        Button dugme = this.Controls.Find("button" + y, true).FirstOrDefault() as Button;
                        if (dugme.Enabled == false)
                        {
                            while (dugme.Enabled == false)
                            {
                                y = x.Next(9, 17);
                                dugme = this.Controls.Find("button" + y, true).FirstOrDefault() as Button;
                            }
                        }
                        else
                        {
                            dugme.PerformClick();
                            robot_igra = false;
                        }
                    }             
                }
                if (button_count >= 16 && button_count < 25)
                {
                    for (int i = 16; i < 25; i++)
                    {
                        Random x = new Random();
                        int y = x.Next(16, 25);
                        Button dugme = this.Controls.Find("button" + y, true).FirstOrDefault() as Button;
                        if (dugme.Enabled == false)
                        {
                            while (dugme.Enabled == false)
                            {
                                y = x.Next(16, 25);
                                dugme = this.Controls.Find("button" + y, true).FirstOrDefault() as Button;
                            }
                        }
                        else
                        {
                            dugme.PerformClick();
                            robot_igra = false;
                        }
                    }
                }
                if (button_count >= 24 && button_count < 33)
                {
                    for (int i = 24; i < 33; i++)
                    {
                        Random x = new Random();
                        int y = x.Next(24, 33);
                        Button dugme = this.Controls.Find("button" + y, true).FirstOrDefault() as Button;
                        if (dugme.Enabled == false)
                        {
                            while (dugme.Enabled == false)
                            {
                                y = x.Next(24, 33);
                                dugme = this.Controls.Find("button" + y, true).FirstOrDefault() as Button;
                            }
                        }
                        else
                        {
                            dugme.PerformClick();
                            robot_igra = false;
                        }
                    }
                }
                if (button_count >= 32 && button_count < 41)
                {
                    for (int i = 32; i < 41; i++)
                    {
                        Random x = new Random();
                        int y = x.Next(32, 41);
                        Button dugme = this.Controls.Find("button" + y, true).FirstOrDefault() as Button;
                        if (dugme.Enabled == false)
                        {
                            while (dugme.Enabled == false)
                            {
                                y = x.Next(32, 41);
                                dugme = this.Controls.Find("button" + y, true).FirstOrDefault() as Button;
                            }
                        }
                        else
                        {
                            dugme.PerformClick();
                            robot_igra = false;
                        }
                    }
                }
                if (button_count >= 40 && button_count < 49)
                {
                    for (int i = 40; i < 49; i++)
                    {
                        Random x = new Random();
                        int y = x.Next(40, 49);
                        Button dugme = this.Controls.Find("button" + y, true).FirstOrDefault() as Button;
                        if (dugme.Enabled == false)
                        {
                            while (dugme.Enabled == false)
                            {
                                y = x.Next(40, 49);
                                dugme = this.Controls.Find("button" + y, true).FirstOrDefault() as Button;
                            }
                        }
                        else
                        {
                            dugme.PerformClick();
                            robot_igra = false;
                        }
                    }
                }
                if (button_count >= 48 && button_count < 57)
                {
                    for (int i = 48; i < 57; i++)
                    {
                        Random x = new Random();
                        int y = x.Next(48, 57);
                        Button dugme = this.Controls.Find("button" + y, true).FirstOrDefault() as Button;
                        if (dugme.Enabled == false)
                        {
                            while (dugme.Enabled == false)
                            {
                                y = x.Next(48, 57);
                                dugme = this.Controls.Find("button" + y, true).FirstOrDefault() as Button;
                            }
                        }
                        else
                        {
                            dugme.PerformClick();
                            robot_igra = false;
                        }
                    }
                }
                if (button_count >= 56 && button_count < 65)
                {
                    for (int i = 56; i < 65; i++)
                    {
                        Random x = new Random();
                        int y = x.Next(56, 65);
                        Button dugme = this.Controls.Find("button" + y, true).FirstOrDefault() as Button;
                        if (dugme.Enabled == false)
                        {
                            while (dugme.Enabled == false)
                            {
                                y = x.Next(56, 65);
                                dugme = this.Controls.Find("button" + y, true).FirstOrDefault() as Button;
                            }
                        }
                        else
                        {
                            dugme.PerformClick();
                            robot_igra = false;
                        }
                    }
                }
            }
        }


        //provera niza
        private void timer3_Tick(object sender, EventArgs e)
        {

        }
    }
}
