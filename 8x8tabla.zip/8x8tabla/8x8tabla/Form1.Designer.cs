﻿namespace _8x8tabla
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.button37 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.button43 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.button45 = new System.Windows.Forms.Button();
            this.button46 = new System.Windows.Forms.Button();
            this.button47 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.button49 = new System.Windows.Forms.Button();
            this.button50 = new System.Windows.Forms.Button();
            this.button51 = new System.Windows.Forms.Button();
            this.button52 = new System.Windows.Forms.Button();
            this.button53 = new System.Windows.Forms.Button();
            this.button54 = new System.Windows.Forms.Button();
            this.button55 = new System.Windows.Forms.Button();
            this.button56 = new System.Windows.Forms.Button();
            this.button57 = new System.Windows.Forms.Button();
            this.button58 = new System.Windows.Forms.Button();
            this.button59 = new System.Windows.Forms.Button();
            this.button60 = new System.Windows.Forms.Button();
            this.button61 = new System.Windows.Forms.Button();
            this.button62 = new System.Windows.Forms.Button();
            this.button63 = new System.Windows.Forms.Button();
            this.button64 = new System.Windows.Forms.Button();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Location = new System.Drawing.Point(2, 393);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(50, 50);
            this.button1.TabIndex = 0;
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Location = new System.Drawing.Point(226, 393);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(50, 50);
            this.button2.TabIndex = 1;
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Location = new System.Drawing.Point(170, 393);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(50, 50);
            this.button3.TabIndex = 2;
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Location = new System.Drawing.Point(114, 393);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(50, 50);
            this.button4.TabIndex = 3;
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Location = new System.Drawing.Point(58, 393);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(50, 50);
            this.button5.TabIndex = 4;
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button6.Location = new System.Drawing.Point(394, 393);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(50, 50);
            this.button6.TabIndex = 5;
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button7.Location = new System.Drawing.Point(338, 393);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(50, 50);
            this.button7.TabIndex = 6;
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button8.Location = new System.Drawing.Point(282, 393);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(50, 50);
            this.button8.TabIndex = 7;
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button9.Location = new System.Drawing.Point(282, 337);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(50, 50);
            this.button9.TabIndex = 15;
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button10.Location = new System.Drawing.Point(338, 337);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(50, 50);
            this.button10.TabIndex = 14;
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button11.Location = new System.Drawing.Point(394, 337);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(50, 50);
            this.button11.TabIndex = 13;
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button12.Location = new System.Drawing.Point(58, 337);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(50, 50);
            this.button12.TabIndex = 12;
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button13.Location = new System.Drawing.Point(114, 337);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(50, 50);
            this.button13.TabIndex = 11;
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button14.Location = new System.Drawing.Point(170, 337);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(50, 50);
            this.button14.TabIndex = 10;
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button15.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button15.Location = new System.Drawing.Point(226, 337);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(50, 50);
            this.button15.TabIndex = 9;
            this.button15.UseVisualStyleBackColor = false;
            this.button15.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button16
            // 
            this.button16.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button16.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button16.Location = new System.Drawing.Point(2, 337);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(50, 50);
            this.button16.TabIndex = 8;
            this.button16.UseVisualStyleBackColor = false;
            this.button16.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button17
            // 
            this.button17.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button17.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button17.Location = new System.Drawing.Point(282, 281);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(50, 50);
            this.button17.TabIndex = 23;
            this.button17.UseVisualStyleBackColor = false;
            this.button17.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button18.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button18.Location = new System.Drawing.Point(338, 281);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(50, 50);
            this.button18.TabIndex = 22;
            this.button18.UseVisualStyleBackColor = false;
            this.button18.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button19
            // 
            this.button19.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button19.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button19.Location = new System.Drawing.Point(394, 281);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(50, 50);
            this.button19.TabIndex = 21;
            this.button19.UseVisualStyleBackColor = false;
            this.button19.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button20
            // 
            this.button20.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button20.Location = new System.Drawing.Point(58, 281);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(50, 50);
            this.button20.TabIndex = 20;
            this.button20.UseVisualStyleBackColor = false;
            this.button20.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button21
            // 
            this.button21.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button21.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button21.Location = new System.Drawing.Point(114, 281);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(50, 50);
            this.button21.TabIndex = 19;
            this.button21.UseVisualStyleBackColor = false;
            this.button21.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button22
            // 
            this.button22.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button22.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button22.Location = new System.Drawing.Point(170, 281);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(50, 50);
            this.button22.TabIndex = 18;
            this.button22.UseVisualStyleBackColor = false;
            this.button22.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button23
            // 
            this.button23.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button23.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button23.Location = new System.Drawing.Point(226, 281);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(50, 50);
            this.button23.TabIndex = 17;
            this.button23.UseVisualStyleBackColor = false;
            this.button23.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button24
            // 
            this.button24.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button24.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button24.Location = new System.Drawing.Point(2, 281);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(50, 50);
            this.button24.TabIndex = 16;
            this.button24.UseVisualStyleBackColor = false;
            this.button24.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button25
            // 
            this.button25.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button25.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button25.Location = new System.Drawing.Point(282, 225);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(50, 50);
            this.button25.TabIndex = 31;
            this.button25.UseVisualStyleBackColor = false;
            this.button25.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button26
            // 
            this.button26.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button26.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button26.Location = new System.Drawing.Point(338, 225);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(50, 50);
            this.button26.TabIndex = 30;
            this.button26.UseVisualStyleBackColor = false;
            this.button26.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button27
            // 
            this.button27.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button27.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button27.Location = new System.Drawing.Point(394, 225);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(50, 50);
            this.button27.TabIndex = 29;
            this.button27.UseVisualStyleBackColor = false;
            this.button27.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button28
            // 
            this.button28.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button28.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button28.Location = new System.Drawing.Point(58, 225);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(50, 50);
            this.button28.TabIndex = 28;
            this.button28.UseVisualStyleBackColor = false;
            this.button28.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button29
            // 
            this.button29.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button29.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button29.Location = new System.Drawing.Point(114, 225);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(50, 50);
            this.button29.TabIndex = 27;
            this.button29.UseVisualStyleBackColor = false;
            this.button29.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button30
            // 
            this.button30.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button30.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button30.Location = new System.Drawing.Point(170, 225);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(50, 50);
            this.button30.TabIndex = 26;
            this.button30.UseVisualStyleBackColor = false;
            this.button30.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button31
            // 
            this.button31.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button31.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button31.Location = new System.Drawing.Point(226, 225);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(50, 50);
            this.button31.TabIndex = 25;
            this.button31.UseVisualStyleBackColor = false;
            this.button31.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button32
            // 
            this.button32.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button32.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button32.Location = new System.Drawing.Point(2, 225);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(50, 50);
            this.button32.TabIndex = 24;
            this.button32.UseVisualStyleBackColor = false;
            this.button32.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button33
            // 
            this.button33.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button33.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button33.Location = new System.Drawing.Point(282, 169);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(50, 50);
            this.button33.TabIndex = 39;
            this.button33.UseVisualStyleBackColor = false;
            this.button33.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button34
            // 
            this.button34.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button34.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button34.Location = new System.Drawing.Point(338, 169);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(50, 50);
            this.button34.TabIndex = 38;
            this.button34.UseVisualStyleBackColor = false;
            this.button34.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button35
            // 
            this.button35.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button35.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button35.Location = new System.Drawing.Point(394, 169);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(50, 50);
            this.button35.TabIndex = 37;
            this.button35.UseVisualStyleBackColor = false;
            this.button35.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button36
            // 
            this.button36.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button36.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button36.Location = new System.Drawing.Point(58, 169);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(50, 50);
            this.button36.TabIndex = 36;
            this.button36.UseVisualStyleBackColor = false;
            this.button36.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button37
            // 
            this.button37.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button37.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button37.Location = new System.Drawing.Point(114, 169);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(50, 50);
            this.button37.TabIndex = 35;
            this.button37.UseVisualStyleBackColor = false;
            this.button37.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button38
            // 
            this.button38.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button38.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button38.Location = new System.Drawing.Point(170, 169);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(50, 50);
            this.button38.TabIndex = 34;
            this.button38.UseVisualStyleBackColor = false;
            this.button38.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button39
            // 
            this.button39.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button39.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button39.Location = new System.Drawing.Point(226, 169);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(50, 50);
            this.button39.TabIndex = 33;
            this.button39.UseVisualStyleBackColor = false;
            this.button39.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button40
            // 
            this.button40.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button40.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button40.Location = new System.Drawing.Point(2, 169);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(50, 50);
            this.button40.TabIndex = 32;
            this.button40.UseVisualStyleBackColor = false;
            this.button40.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button41
            // 
            this.button41.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button41.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button41.Location = new System.Drawing.Point(282, 113);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(50, 50);
            this.button41.TabIndex = 47;
            this.button41.UseVisualStyleBackColor = false;
            this.button41.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button42
            // 
            this.button42.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button42.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button42.Location = new System.Drawing.Point(338, 113);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(50, 50);
            this.button42.TabIndex = 46;
            this.button42.UseVisualStyleBackColor = false;
            this.button42.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button43
            // 
            this.button43.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button43.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button43.Location = new System.Drawing.Point(394, 113);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(50, 50);
            this.button43.TabIndex = 45;
            this.button43.UseVisualStyleBackColor = false;
            this.button43.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button44
            // 
            this.button44.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button44.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button44.Location = new System.Drawing.Point(58, 113);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(50, 50);
            this.button44.TabIndex = 44;
            this.button44.UseVisualStyleBackColor = false;
            this.button44.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button45
            // 
            this.button45.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button45.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button45.Location = new System.Drawing.Point(114, 113);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(50, 50);
            this.button45.TabIndex = 43;
            this.button45.UseVisualStyleBackColor = false;
            this.button45.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button46
            // 
            this.button46.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button46.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button46.Location = new System.Drawing.Point(170, 113);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(50, 50);
            this.button46.TabIndex = 42;
            this.button46.UseVisualStyleBackColor = false;
            this.button46.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button47
            // 
            this.button47.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button47.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button47.Location = new System.Drawing.Point(226, 113);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(50, 50);
            this.button47.TabIndex = 41;
            this.button47.UseVisualStyleBackColor = false;
            this.button47.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button48
            // 
            this.button48.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button48.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button48.Location = new System.Drawing.Point(2, 113);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(50, 50);
            this.button48.TabIndex = 40;
            this.button48.UseVisualStyleBackColor = false;
            this.button48.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button49
            // 
            this.button49.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button49.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button49.Location = new System.Drawing.Point(282, 57);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(50, 50);
            this.button49.TabIndex = 55;
            this.button49.UseVisualStyleBackColor = false;
            this.button49.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button50
            // 
            this.button50.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button50.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button50.Location = new System.Drawing.Point(338, 57);
            this.button50.Name = "button50";
            this.button50.Size = new System.Drawing.Size(50, 50);
            this.button50.TabIndex = 54;
            this.button50.UseVisualStyleBackColor = false;
            this.button50.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button51
            // 
            this.button51.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button51.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button51.Location = new System.Drawing.Point(394, 57);
            this.button51.Name = "button51";
            this.button51.Size = new System.Drawing.Size(50, 50);
            this.button51.TabIndex = 53;
            this.button51.UseVisualStyleBackColor = false;
            this.button51.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button52
            // 
            this.button52.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button52.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button52.Location = new System.Drawing.Point(58, 57);
            this.button52.Name = "button52";
            this.button52.Size = new System.Drawing.Size(50, 50);
            this.button52.TabIndex = 52;
            this.button52.UseVisualStyleBackColor = false;
            this.button52.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button53
            // 
            this.button53.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button53.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button53.Location = new System.Drawing.Point(114, 57);
            this.button53.Name = "button53";
            this.button53.Size = new System.Drawing.Size(50, 50);
            this.button53.TabIndex = 51;
            this.button53.UseVisualStyleBackColor = false;
            this.button53.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button54
            // 
            this.button54.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button54.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button54.Location = new System.Drawing.Point(170, 57);
            this.button54.Name = "button54";
            this.button54.Size = new System.Drawing.Size(50, 50);
            this.button54.TabIndex = 50;
            this.button54.UseVisualStyleBackColor = false;
            this.button54.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button55
            // 
            this.button55.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button55.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button55.Location = new System.Drawing.Point(226, 57);
            this.button55.Name = "button55";
            this.button55.Size = new System.Drawing.Size(50, 50);
            this.button55.TabIndex = 49;
            this.button55.UseVisualStyleBackColor = false;
            this.button55.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button56
            // 
            this.button56.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button56.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button56.Location = new System.Drawing.Point(2, 57);
            this.button56.Name = "button56";
            this.button56.Size = new System.Drawing.Size(50, 50);
            this.button56.TabIndex = 48;
            this.button56.UseVisualStyleBackColor = false;
            this.button56.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button57
            // 
            this.button57.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button57.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button57.Location = new System.Drawing.Point(282, 1);
            this.button57.Name = "button57";
            this.button57.Size = new System.Drawing.Size(50, 50);
            this.button57.TabIndex = 63;
            this.button57.UseVisualStyleBackColor = false;
            this.button57.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button58
            // 
            this.button58.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button58.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button58.Location = new System.Drawing.Point(338, 1);
            this.button58.Name = "button58";
            this.button58.Size = new System.Drawing.Size(50, 50);
            this.button58.TabIndex = 62;
            this.button58.UseVisualStyleBackColor = false;
            this.button58.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button59
            // 
            this.button59.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button59.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button59.Location = new System.Drawing.Point(394, 1);
            this.button59.Name = "button59";
            this.button59.Size = new System.Drawing.Size(50, 50);
            this.button59.TabIndex = 61;
            this.button59.UseVisualStyleBackColor = false;
            this.button59.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button60
            // 
            this.button60.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button60.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button60.Location = new System.Drawing.Point(58, 1);
            this.button60.Name = "button60";
            this.button60.Size = new System.Drawing.Size(50, 50);
            this.button60.TabIndex = 60;
            this.button60.UseVisualStyleBackColor = false;
            this.button60.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button61
            // 
            this.button61.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button61.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button61.Location = new System.Drawing.Point(114, 1);
            this.button61.Name = "button61";
            this.button61.Size = new System.Drawing.Size(50, 50);
            this.button61.TabIndex = 59;
            this.button61.UseVisualStyleBackColor = false;
            this.button61.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button62
            // 
            this.button62.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button62.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button62.Location = new System.Drawing.Point(170, 1);
            this.button62.Name = "button62";
            this.button62.Size = new System.Drawing.Size(50, 50);
            this.button62.TabIndex = 58;
            this.button62.UseVisualStyleBackColor = false;
            this.button62.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button63
            // 
            this.button63.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button63.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button63.Location = new System.Drawing.Point(226, 1);
            this.button63.Name = "button63";
            this.button63.Size = new System.Drawing.Size(50, 50);
            this.button63.TabIndex = 57;
            this.button63.UseVisualStyleBackColor = false;
            this.button63.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // button64
            // 
            this.button64.BackColor = System.Drawing.SystemColors.ControlDark;
            this.button64.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button64.Location = new System.Drawing.Point(2, 1);
            this.button64.Name = "button64";
            this.button64.Size = new System.Drawing.Size(50, 50);
            this.button64.TabIndex = 56;
            this.button64.UseVisualStyleBackColor = false;
            this.button64.Click += new System.EventHandler(this.Dugme_Click);
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // timer3
            // 
            this.timer3.Tick += new System.EventHandler(this.timer3_Tick);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.ClientSize = new System.Drawing.Size(445, 446);
            this.Controls.Add(this.button57);
            this.Controls.Add(this.button58);
            this.Controls.Add(this.button59);
            this.Controls.Add(this.button60);
            this.Controls.Add(this.button61);
            this.Controls.Add(this.button62);
            this.Controls.Add(this.button63);
            this.Controls.Add(this.button64);
            this.Controls.Add(this.button49);
            this.Controls.Add(this.button50);
            this.Controls.Add(this.button51);
            this.Controls.Add(this.button52);
            this.Controls.Add(this.button53);
            this.Controls.Add(this.button54);
            this.Controls.Add(this.button55);
            this.Controls.Add(this.button56);
            this.Controls.Add(this.button41);
            this.Controls.Add(this.button42);
            this.Controls.Add(this.button43);
            this.Controls.Add(this.button44);
            this.Controls.Add(this.button45);
            this.Controls.Add(this.button46);
            this.Controls.Add(this.button47);
            this.Controls.Add(this.button48);
            this.Controls.Add(this.button33);
            this.Controls.Add(this.button34);
            this.Controls.Add(this.button35);
            this.Controls.Add(this.button36);
            this.Controls.Add(this.button37);
            this.Controls.Add(this.button38);
            this.Controls.Add(this.button39);
            this.Controls.Add(this.button40);
            this.Controls.Add(this.button25);
            this.Controls.Add(this.button26);
            this.Controls.Add(this.button27);
            this.Controls.Add(this.button28);
            this.Controls.Add(this.button29);
            this.Controls.Add(this.button30);
            this.Controls.Add(this.button31);
            this.Controls.Add(this.button32);
            this.Controls.Add(this.button17);
            this.Controls.Add(this.button18);
            this.Controls.Add(this.button19);
            this.Controls.Add(this.button20);
            this.Controls.Add(this.button21);
            this.Controls.Add(this.button22);
            this.Controls.Add(this.button23);
            this.Controls.Add(this.button24);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button15);
            this.Controls.Add(this.button16);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button50;
        private System.Windows.Forms.Button button51;
        private System.Windows.Forms.Button button52;
        private System.Windows.Forms.Button button53;
        private System.Windows.Forms.Button button54;
        private System.Windows.Forms.Button button55;
        private System.Windows.Forms.Button button56;
        private System.Windows.Forms.Button button57;
        private System.Windows.Forms.Button button58;
        private System.Windows.Forms.Button button59;
        private System.Windows.Forms.Button button60;
        private System.Windows.Forms.Button button61;
        private System.Windows.Forms.Button button62;
        private System.Windows.Forms.Button button63;
        private System.Windows.Forms.Button button64;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Timer timer3;
    }
}

