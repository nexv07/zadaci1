namespace flappybird
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Start();
            button2.Focus();
            button2.Left = 12;
            button2.Top = 225;
            button3.Left = 240;
            button4.Left = 240;
            button5.Left = 533;
            button6.Left = 533;
            button7.Left = 810;
            button8.Left = 810;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            button3.Left -= 5;
            button4.Left -= 5;
            button5.Left -= 5;
            button6.Left -= 5;
            button7.Left -= 5;
            button8.Left -= 5;
            int poeni = Convert.ToInt16(label3.Text);

            Random x = new Random();

            if (button3.Left < -12)
            {
                button3.Left = 1031;
                button4.Left = 1031;
                int vel = x.Next(300);
                button3.Height = vel;
                button4.Height = (410 - (vel + 80));
                button4.Top = vel + 80;
                poeni++;

            }
            if (button5.Left < -12)
            {
                button5.Left = 1031;
                button6.Left = 1031;
                int vel = x.Next(300);
                button5.Height = vel;
                button6.Height = (410 - (vel + 80));
                button6.Top = vel + 80;
                poeni++;

            }

            if (button7.Left < -12)
            {
                button7.Left = 1031;
                button8.Left = 1031;
                int vel = x.Next(300);
                button7.Height = vel;
                button8.Height = (410 - (vel + 80));
                button8.Top = vel + 80;
                poeni++;

            }

            label3.Text = Convert.ToString(poeni);
        }

        private void button2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 'a') button2.Left -= 5;
            if (e.KeyChar == 's') button2.Top += 5;
            if (e.KeyChar == 'd') button2.Left += 5;
            if (e.KeyChar == 'w') button2.Top -= 5;

            if (button2.Left < 0) button2.Left = 0;
            if (button2.Left > 1001) button2.Left = 1001;
            if (button2.Top < 0) button2.Top = 0;
            if (button2.Top > 550) button2.Top = 500;

            if (button2.Bounds.IntersectsWith(button3.Bounds))
            {
                timer1.Stop();
                MessageBox.Show("GAME OVER");
            }
            if (button2.Bounds.IntersectsWith(button4.Bounds))
            {
                timer1.Stop();
                MessageBox.Show("GAME OVER");
            }
            if (button2.Bounds.IntersectsWith(button5.Bounds))
            {
                timer1.Stop();
                MessageBox.Show("GAME OVER");
            }
            if (button2.Bounds.IntersectsWith(button6.Bounds))
            {
                timer1.Stop();
                MessageBox.Show("GAME OVER");
            }
            if (button2.Bounds.IntersectsWith(button7.Bounds))
            {
                timer1.Stop();
                MessageBox.Show("GAME OVER");
            }
            if (button2.Bounds.IntersectsWith(button8.Bounds))
            {
                timer1.Stop();
                MessageBox.Show("GAME OVER");
            }
        }
    }
}
