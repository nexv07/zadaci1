﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace lista2
{
    public partial class Form1 : Form
    {
        string prazno = "                         ";

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string s1 = textBox1.Text.PadRight(10);  // Poravnavanje na desno, širina 10
            string s2 = textBox2.Text.PadRight(15);  // Poravnavanje na desno, širina 15
            string s3 = textBox3.Text.PadLeft(10);   // Poravnavanje na levo, širina 10

            string s = s1 + s2 + s3;
            listBox1.Items.Add(s);
            listBox2.Items.Add(s);
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
        }

        private void listBox1_Click(object sender, EventArgs e)
        {
            int x = listBox1.SelectedIndex;
            string s = listBox1.Items[x].ToString();
            string s1 = s.Substring(0, 10);
            string s2 = s.Substring(10, 15);
            string s3 = s.Substring(25, 10);

            int z = Convert.ToInt32(s1);
            s1 = Convert.ToString(z);
            double d1 = Convert.ToDouble(s3);
            s3 = Convert.ToString(d1);

            textBox1.Text = s1;
            textBox2.Text = s2;
            textBox3.Text = s3;
        }

        private void listBox2_Click(object sender, EventArgs e)
        {
            int x = listBox2.SelectedIndex;
            string s = listBox2.Items[x].ToString();
            string s1 = s.Substring(0, 10);
            string s2 = s.Substring(10, 15);
            string s3 = s.Substring(25, 10);

            int z = Convert.ToInt32(s1);
            s1 = Convert.ToString(z);
            double d1 = Convert.ToDouble(s3);
            s3 = Convert.ToString(d1);

            textBox6.Text = s1;
            textBox5.Text = s2;
            textBox4.Text = s3;
        }

        private void button2_Click(object sender, EventArgs e)
        {
           
        
            // Poravnaj sve stringove sa odgovarajućim širinama
            string s1 = textBox6.Text.PadRight(10);  // Širina 10
            string s2 = textBox5.Text.PadRight(15);  // Širina 15
            string s3 = textBox4.Text.PadLeft(10);   // Širina 10, poravnanje sa desne strane
            string s4 = textBox7.Text.PadRight(10);  // Širina 10

            int x= Convert.ToInt32(s3);
            int y= Convert.ToInt32(s4);
            int z = x * y;
            string s5=Convert.ToString(z);
            // Kombinuj sve delove u jedan string
            string s = s1 + s2 + s3 + prazno + s4 + prazno + s5;
            ;

            // Dodaj sve u listBox3
            listBox3.Items.Add(s);

            // Očisti sve textBox-ove
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
       
    }
}
}
