﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace listbox_sa_recima
{

    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            label1.Text = "0";
            label2.Text = "0";
            label3.Text = "0";
            listBox1.Items.Clear();
            listBox2.Items.Clear();
            listBox3.Items.Clear();
            Random x = new Random();
            for (int i = 0; i < 10; i++)
            {
                string z = "";
                for (int j = 0; j < 5; j++)
                {
                    int sluc = x.Next(65, 90);


                    z = z + Convert.ToChar(sluc);
                }
                listBox1.Items.Add(z);
            }
            Random y = new Random();
            int sluc2 = y.Next(65, 90);
            int sluc3 = y.Next(65, 90);
            int temp2, temp3;
            temp2 = Convert.ToChar(sluc2);
            temp3 = Convert.ToChar(sluc3);
            label2.Text = Convert.ToString(temp2);
            label3.Text = Convert.ToString(temp3);


        }

        private void drugi_Click(object sender, EventArgs e)
        {

            int tren = listBox1.SelectedIndex;
            string temp = listBox1.Items[tren].ToString();
            int nesto = Convert.ToInt32(label2.Text);

            listBox2.Items.Add(temp);
            listBox1.Items.RemoveAt(tren);
        }
        
        

        private void treci_Click(object sender, EventArgs e)
        {

            int tren = listBox1.SelectedIndex;
            string temp = listBox1.Items[tren].ToString();
            listBox3.Items.Add(temp);
            listBox1.Items.RemoveAt(tren);
        }
    }
}



