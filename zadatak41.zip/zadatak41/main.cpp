#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
using namespace std;

int main()
{
    srand(time(0));
    int daske = 0, daska1x1 = 0, daska1x2 = 0, daska1x3 = 0, daska1x4 = 0, daska1x5 = 0, daska1x6 = 0, daska1x7 = 0, daska1x8 = 0, daska1x9 = 0, daska1x10 = 0;
    int niz[10][10];
    bool obradjeni[10][10] = {false};

    // Popunjava niz sa slučajnim vrednostima (0 ili 1)
    for (int i = 0; i < 10; i++) {
        for (int j = 0; j < 10; j++) {
            niz[i][j] = rand() % 2;
        }
    }

    // Ispisivanje niza
    for (int i = 0; i < 10; i++) {
        for (int j = 0; j < 10; j++) {
            printf("%d ", niz[i][j]);
        }
        printf("\n");
    }

    // Kombinovana pretraga po redovima i kolonama
    for (int i = 0; i < 10; i++) {
        for (int j = 0; j < 10; j++) {
            // Ako je nula i nije još obrađena u redu
            if (niz[i][j] == 0 && !obradjeni[i][j]) {
                // Pretraga po redu
                int duzinaReda = 0;
                while (j + duzinaReda < 10 && niz[i][j + duzinaReda] == 0 && !obradjeni[i][j + duzinaReda]) {
                    duzinaReda++;
                }

                // Obeležavanje obrađenih pozicija u redu
                for (int k = 0; k < duzinaReda; k++) {
                    obradjeni[i][j + k] = true;
                }

                // Prebrojavanje dužine u redu
                if (duzinaReda == 10) {
                    daske++;
                    daska1x10++;
                } else if (duzinaReda == 9) {
                    daske++;
                    daska1x9++;
                } else if (duzinaReda == 8) {
                    daske++;
                    daska1x8++;
                } else if (duzinaReda == 7) {
                    daske++;
                    daska1x7++;
                } else if (duzinaReda == 6) {
                    daske++;
                    daska1x6++;
                } else if (duzinaReda == 5) {
                    daske++;
                    daska1x5++;
                } else if (duzinaReda == 4) {
                    daske++;
                    daska1x4++;
                } else if (duzinaReda == 3) {
                    daske++;
                    daska1x3++;
                } else if (duzinaReda == 2) {
                    daske++;
                    daska1x2++;
                } else {
                    daske++;
                    daska1x1++;
                }

                // Nastavi dalje u redu
                j += duzinaReda - 1;
            }

            // Ako je nula i nije još obrađena u koloni
            if (niz[j][i] == 0 && !obradjeni[j][i]) {
                // Pretraga po koloni
                int duzinaKolone = 0;
                while (j + duzinaKolone < 10 && niz[j + duzinaKolone][i] == 0 && !obradjeni[j + duzinaKolone][i]) {
                    duzinaKolone++;
                }

                // Obeležavanje obrađenih pozicija u koloni
                for (int k = 0; k < duzinaKolone; k++) {
                    obradjeni[j + k][i] = true;
                }

                // Prebrojavanje dužine u koloni
                if (duzinaKolone == 10) {
                    daske++;
                    daska1x10++;
                } else if (duzinaKolone == 9) {
                    daske++;
                    daska1x9++;
                } else if (duzinaKolone == 8) {
                    daske++;
                    daska1x8++;
                } else if (duzinaKolone == 7) {
                    daske++;
                    daska1x7++;
                } else if (duzinaKolone == 6) {
                    daske++;
                    daska1x6++;
                } else if (duzinaKolone == 5) {
                    daske++;
                    daska1x5++;
                } else if (duzinaKolone == 4) {
                    daske++;
                    daska1x4++;
                } else if (duzinaKolone == 3) {
                    daske++;
                    daska1x3++;
                } else if (duzinaKolone == 2) {
                    daske++;
                    daska1x2++;
                } else {
                    daske++;
                    daska1x1++;
                }

                // Nastavi dalje u koloni
                j += duzinaKolone - 1;
            }
        }
    }

    // Ispisivanje broja dasaka po dužini
    printf("\n\nBroj 1x1 dasaka : %d", daska1x1);
    printf("\nBroj 1x2 dasaka : %d", daska1x2);
    printf("\nBroj 1x3 dasaka : %d", daska1x3);
    printf("\nBroj 1x4 dasaka : %d", daska1x4);
    printf("\nBroj 1x5 dasaka : %d", daska1x5);
    printf("\nBroj 1x6 dasaka : %d", daska1x6);
    printf("\nBroj 1x7 dasaka : %d", daska1x7);
    printf("\nBroj 1x8 dasaka : %d", daska1x8);
    printf("\nBroj 1x9 dasaka : %d", daska1x9);
    printf("\nBroj 1x10 dasaka : %d", daska1x10);

    printf("\n\nBroj dasaka potreban za pokrivanje blata je %d", daske);

    return 0;
}
