﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace racunanje_izraza
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            textBox1.Focus();
            
        }
        
        private void button1_Click(object sender, EventArgs e)
        {       
            string izraz = textBox1.Text;
            //var rezultat = new DataTable().Compute(izraz, null);
            //textBox2.Text = rezultat.ToString();
            int rezultat = 0;
            string trenutniBroj = "";
            char poslednjiOperator = '+';
            int otvoreneZagrade = 0;

            for (int i = 0; i < izraz.Length; i++)
            {
                char trenutniZnak = izraz[i];
                if (char.IsDigit(trenutniZnak))
                {
                    trenutniBroj += trenutniZnak;
                    DataGridViewAutoSizeColumnModeEventArgs.ReferenceEquals.
                }
                else if (trenutniZnak == '(')
                {
                    otvoreneZagrade++;
                }
                else if (trenutniZnak == ')')
                {
                    otvoreneZagrade--;
                }
                else if ((trenutniZnak == '+' || trenutniZnak == '-' || trenutniZnak == '*' || trenutniZnak == '/') && otvoreneZagrade == 0)

                {
                    if (trenutniBroj != "")

                    {                  
                        int broj = int.Parse(trenutniBroj);
                        switch (poslednjiOperator)
                        {
                            case '+':
                                rezultat += broj;
                                break;
                            case '-':
                                rezultat -= broj;
                                break;
                            case '*':
                                rezultat *= broj;
                                break;
                            case '/':
                                rezultat /= broj;
                                break;
                        }
                        trenutniBroj = "";
                    }
                    poslednjiOperator = trenutniZnak;
                }

            }
            if (trenutniBroj != "")
            {
                int broj = int.Parse(trenutniBroj);
                switch (poslednjiOperator)
                {
                    case '+':
                        rezultat += broj;
                        break;
                    case '-':
                        rezultat -= broj;
                        break;
                    case '*':
                        rezultat *= broj;
                        break;
                    case '/':
                        rezultat /= broj;
                        break;
                }

            }
            textBox2.Text = rezultat.ToString();
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 13) button1.PerformClick();
        }
    }
}
