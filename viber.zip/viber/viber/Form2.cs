﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace viber
{
    public partial class Form2 : Form
    {
        private string imetxt;
        public Form2(string imetxt)
        {
            InitializeComponent();
            this.imetxt = imetxt;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string txt;
            txt = imetxt + textBox1.Text;
            listBox1.Items.Add(txt);
            textBox1.Text = "";
            textBox1.ResetText();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            kopiraj.PerformClick();
            richTextBox1.SaveFile(@"D:\III PROGRAMIRANJE\Grupa A\NEMANJA VUKASINOVIC\poruke.txt", RichTextBoxStreamType.PlainText);
        }

        private void kopiraj_Click(object sender, EventArgs e)
        {
            richTextBox1.Clear();
            char enter = Convert.ToChar(13);
            int x = listBox1.Items.Count;
            for (int i = 0; i < x; i++)
            {
                string s = listBox1.Items[i].ToString();
                richTextBox1.Text = s + enter;
            }
        }

        private void ucitaj_Click(object sender, EventArgs e)
        {
            richTextBox1.Clear();
            richTextBox1.LoadFile(@"D:\III PROGRAMIRANJE\Grupa A\NEMANJA VUKASINOVIC\poruke.txt", RichTextBoxStreamType.PlainText);
            int x = richTextBox1.Lines.Count();
            for (int i = 0; i < x; i++)
            {
                string s = richTextBox1.Lines[i];
                if (s != "") listBox1.Items.Add(s);
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            ucitaj.PerformClick();
        }
    }
}
