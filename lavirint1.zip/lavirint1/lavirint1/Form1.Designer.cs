﻿namespace lavirint1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            button10 = new Button();
            button11 = new Button();
            button12 = new Button();
            timer1 = new System.Windows.Forms.Timer(components);
            SuspendLayout();
            // 
            // label1
            // 
            label1.BackColor = Color.FromArgb(255, 224, 192);
            label1.Dock = DockStyle.Top;
            label1.Location = new Point(0, 0);
            label1.Name = "label1";
            label1.Size = new Size(984, 59);
            label1.TabIndex = 0;
            // 
            // label2
            // 
            label2.BackColor = Color.FromArgb(255, 224, 192);
            label2.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            label2.Location = new Point(45, 9);
            label2.Name = "label2";
            label2.Size = new Size(80, 40);
            label2.TabIndex = 1;
            label2.Text = "VREME";
            label2.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            label3.BackColor = Color.FromArgb(255, 224, 192);
            label3.Font = new Font("Segoe UI", 15F, FontStyle.Bold);
            label3.Location = new Point(131, 15);
            label3.Name = "label3";
            label3.Size = new Size(52, 36);
            label3.TabIndex = 2;
            label3.Text = "30";
            // 
            // button1
            // 
            button1.BackColor = Color.Red;
            button1.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
            button1.ForeColor = SystemColors.ControlLightLight;
            button1.Location = new Point(799, 14);
            button1.Name = "button1";
            button1.Size = new Size(104, 37);
            button1.TabIndex = 3;
            button1.Text = "START";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.FromArgb(0, 192, 0);
            button2.Location = new Point(12, 77);
            button2.Name = "button2";
            button2.Size = new Size(25, 25);
            button2.TabIndex = 4;
            button2.UseVisualStyleBackColor = false;
            button2.KeyPress += button2_KeyPress;
            // 
            // button3
            // 
            button3.BackColor = Color.FromArgb(128, 255, 255);
            button3.Location = new Point(0, 117);
            button3.Name = "button3";
            button3.Size = new Size(360, 23);
            button3.TabIndex = 5;
            button3.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            button4.BackColor = Color.FromArgb(128, 255, 255);
            button4.Location = new Point(422, 58);
            button4.Name = "button4";
            button4.Size = new Size(23, 162);
            button4.TabIndex = 6;
            button4.UseVisualStyleBackColor = false;
            // 
            // button5
            // 
            button5.BackColor = Color.FromArgb(128, 255, 255);
            button5.Location = new Point(117, 188);
            button5.Name = "button5";
            button5.Size = new Size(308, 32);
            button5.TabIndex = 7;
            button5.UseVisualStyleBackColor = false;
            // 
            // button6
            // 
            button6.BackColor = Color.FromArgb(128, 255, 255);
            button6.Location = new Point(117, 281);
            button6.Name = "button6";
            button6.Size = new Size(30, 180);
            button6.TabIndex = 8;
            button6.UseVisualStyleBackColor = false;
            // 
            // button7
            // 
            button7.BackColor = Color.FromArgb(128, 255, 255);
            button7.Location = new Point(224, 352);
            button7.Name = "button7";
            button7.Size = new Size(688, 23);
            button7.TabIndex = 9;
            button7.UseVisualStyleBackColor = false;
            // 
            // button8
            // 
            button8.BackColor = Color.FromArgb(128, 255, 255);
            button8.Location = new Point(224, 217);
            button8.Name = "button8";
            button8.Size = new Size(75, 137);
            button8.TabIndex = 10;
            button8.UseVisualStyleBackColor = false;
            // 
            // button9
            // 
            button9.BackColor = Color.Yellow;
            button9.Location = new Point(351, 259);
            button9.Name = "button9";
            button9.Size = new Size(55, 53);
            button9.TabIndex = 11;
            button9.Text = "X";
            button9.UseVisualStyleBackColor = false;
            // 
            // button10
            // 
            button10.BackColor = Color.FromArgb(128, 255, 255);
            button10.Location = new Point(837, 117);
            button10.Name = "button10";
            button10.Size = new Size(75, 237);
            button10.TabIndex = 12;
            button10.UseVisualStyleBackColor = false;
            // 
            // button11
            // 
            button11.BackColor = Color.FromArgb(128, 255, 255);
            button11.Location = new Point(534, 117);
            button11.Name = "button11";
            button11.Size = new Size(306, 40);
            button11.TabIndex = 13;
            button11.UseVisualStyleBackColor = false;
            // 
            // button12
            // 
            button12.BackColor = Color.FromArgb(128, 255, 255);
            button12.Location = new Point(442, 197);
            button12.Name = "button12";
            button12.Size = new Size(327, 23);
            button12.TabIndex = 14;
            button12.UseVisualStyleBackColor = false;
            // 
            // timer1
            // 
            timer1.Interval = 1000;
            timer1.Tick += timer1_Tick;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(192, 255, 192);
            ClientSize = new Size(984, 461);
            Controls.Add(button12);
            Controls.Add(button11);
            Controls.Add(button10);
            Controls.Add(button9);
            Controls.Add(button8);
            Controls.Add(button7);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form1";
            Text = "Form1";
            ResumeLayout(false);
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button10;
        private Button button11;
        private Button button12;
        private System.Windows.Forms.Timer timer1;
    }
}
