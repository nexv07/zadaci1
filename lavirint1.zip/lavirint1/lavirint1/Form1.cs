namespace lavirint1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }




        private void timer1_Tick(object sender, EventArgs e)
        {
            int vreme = Convert.ToInt16(label3.Text);
            vreme--;
            label3.Text = Convert.ToString(vreme);
            if (vreme == 0)
            {
                timer1.Stop();
                MessageBox.Show("GAME OVER");
                button1.Left = 12;
                button1.Top = 76;
                timer1.Stop();

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            button2.Focus();
            timer1.Start();
            label3.Text = "30";
            button2.Left = 12;
            button2.Top = 77;

        }

        private void button2_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == 'a') button2.Left -= 10;
            if (e.KeyChar == 's') button2.Top += 10;
            if (e.KeyChar == 'd') button2.Left += 10;
            if (e.KeyChar == 'w') button2.Top -= 10;

            if (button2.Bounds.IntersectsWith(label1.Bounds))
            {
                button2.Left = 12;
                button2.Top = 77;
            }
            if (button2.Bounds.IntersectsWith(button3.Bounds))
            {
                timer1.Stop();
                button2.Left = 12;
                button2.Top = 77;
                MessageBox.Show("GAME OVER");
            }
            if (button2.Bounds.IntersectsWith(button4.Bounds))
            {
                timer1.Stop();
                button2.Left = 12;
                button2.Top = 77;
                MessageBox.Show("GAME OVER");
            }
            if (button2.Bounds.IntersectsWith(button5.Bounds))
            {
                timer1.Stop();
                button2.Left = 12;
                button2.Top = 77;
                MessageBox.Show("GAME OVER");
            }
            if (button2.Bounds.IntersectsWith(button6.Bounds))
            {
                timer1.Stop();
                button2.Left = 12;
                button2.Top = 77;
                MessageBox.Show("GAME OVER");
            }
            if (button2.Bounds.IntersectsWith(button7.Bounds))
            {
                timer1.Stop();
                button2.Left = 12;
                button2.Top = 77;
                MessageBox.Show("GAME OVER");
            }
            if (button2.Bounds.IntersectsWith(button8.Bounds))
            {
                timer1.Stop();
                button2.Left = 12;
                button2.Top = 77;
                MessageBox.Show("GAME OVER");
            }
            if (button2.Bounds.IntersectsWith(button9.Bounds))
            {
                timer1.Stop();
                button2.Left = 12;
                button2.Top = 77;
                MessageBox.Show("VICTORY");
            }
            if (button2.Bounds.IntersectsWith(button10.Bounds))
            {
                timer1.Stop();
                button2.Left = 12;
                button2.Top = 77;
                MessageBox.Show("GAME OVER");
            }
            if (button2.Bounds.IntersectsWith(button11.Bounds))
            {
                timer1.Stop();
                button2.Left = 12;
                button2.Top = 77;
                MessageBox.Show("GAME OVER");
            }
            if (button2.Bounds.IntersectsWith(button12.Bounds))
            {
                timer1.Stop();
                button2.Left = 12;
                button2.Top = 77;
                MessageBox.Show("GAME OVER");
            }


        }

    }
}
