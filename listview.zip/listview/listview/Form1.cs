﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace listview
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string s1 = textBox1.Text;
            string s2 = textBox2.Text;
            string s3 = textBox3.Text;
            string[] zapis = { s1, s2, s3 };
            var red1 = new ListViewItem(zapis);
            var red2 = new ListViewItem(zapis);
            listView1.Items.Add(red1);
            listView2.Items.Add(red2);
            textBox1.Text = "";
            textBox2.Text = "";
            textBox3.Text = "";
        }

        private void listView2_Click(object sender, EventArgs e)
        {
            int x = listView2.FocusedItem.Index;
            textBox6.Text = listView2.Items[x].SubItems[0].Text;
            textBox5.Text = listView2.Items[x].SubItems[1].Text;
            textBox4.Text = listView2.Items[x].SubItems[2].Text;
        }

        private void listView1_Click(object sender, EventArgs e)
        {
            int x = listView1.FocusedItem.Index;
            label1.Text = Convert.ToString(x);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            int x = Convert.ToInt16(label1.Text);
            listView1.Items.RemoveAt(x);
            listView2.Items.RemoveAt(x);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string s1 = textBox6.Text;
            string s2 = textBox5.Text;
            string s3 = textBox4.Text;
            string s4 = textBox7.Text;
            int x = Convert.ToInt16(s3);
            int z = Convert.ToInt16(s4);
            int kolonaukp = x * z;
            int sveukp = Convert.ToInt16(label9.Text);
            sveukp = sveukp + kolonaukp;
            label9.Text = Convert.ToString(sveukp);
            string s5 = Convert.ToString(kolonaukp);
            string[] zapis = { s1, s2, s3, s4, s5 };
            var red1 = new ListViewItem(zapis);
            listView3.Items.Add(red1);
        }
    }
}
