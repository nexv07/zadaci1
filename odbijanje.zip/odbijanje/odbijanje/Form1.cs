namespace odbijanje
{
    public partial class Form1 : Form
    {
        int px = 2, py = 2, px1 = 4, py1 = 4, px2 = 5, py2 = 5, px3 = 6, py3 = 6;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label2.Text = "0";
            button2.Enabled = true;
            button2.Focus();
            timer1.Start();
            timer2.Start();
            button2.Left = 49;
            button2.Top = 141;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            //prvi
            button3.Left += px;
            button3.Top += py;
            if (button3.Top > 386) py = (-1) * py;
            if (button3.Left > 564) px = (-1) * px;
            if (button3.Top < 0) py = (-1) * py;
            if (button3.Left < 0) px = (-1) * px;
            //drugi
            button4.Left -= px1;
            button4.Top += py1;
            if (button4.Top > 386) py1 = (-1) * py1;
            if (button4.Left > 564) px1 = (-1) * px1;
            if (button4.Top < 0) py1 = (-1) * py1;
            if (button4.Left < 0) px1 = (-1) * px1;
            //treci
            button6.Left -= px2;
            button6.Top -= py2;
            if (button6.Top > 386) py2 = (-1) * py2;
            if (button6.Left > 564) px2 = (-1) * px2;
            if (button6.Top < 0) py2 = (-1) * py2;
            if (button6.Left < 0) px2 = (-1) * px2;
            //cetvrti
            button5.Left -= px3;
            button5.Top -= py3;
            if (button5.Top > 386) py3 = (-1) * py3;
            if (button5.Left > 564) px3 = (-1) * px3;
            if (button5.Top < 0) py3 = (-1) * py3;
            if (button5.Left < 0) px3 = (-1) * px3;
        }






        private void button2_KeyPress(object sender, KeyPressEventArgs e)
        {
            //kretanje
            if (e.KeyChar == 'a') button2.Left -= 10;
            if (e.KeyChar == 's') button2.Top += 10;
            if (e.KeyChar == 'd') button2.Left += 10;
            if (e.KeyChar == 'w') button2.Top -= 10;
            //igrac borderi
            if (button2.Left > 554) button2.Left = 558;
            if (button2.Top > 376) button2.Top = 375;
            if (button2.Left < 0) button2.Left = 1;
            if (button2.Top < 0) button2.Top = 1;

            //borderi
            if (button2.Bounds.IntersectsWith(button7.Bounds))
            {
                //poeni
                int poeni = Convert.ToInt32(label2.Text);
                poeni++;
                (label2.Text) = Convert.ToString(poeni);


                Random x = new Random();
                button7.Left = x.Next(559);
                button7.Top = x.Next(391);
            }
            if (button2.Bounds.IntersectsWith(button3.Bounds))
            {
                timer1.Stop();
                timer2.Stop();
                button2.Enabled = false;
                MessageBox.Show("GAME OVER");
            }
            if (button2.Bounds.IntersectsWith(button4.Bounds))
            {
                timer1.Stop();
                timer2.Stop();
                button2.Enabled = false;
                MessageBox.Show("GAME OVER");
            }
            if (button2.Bounds.IntersectsWith(button6.Bounds))
            {
                timer1.Stop();
                timer2.Stop();
                button2.Enabled = false;
                MessageBox.Show("GAME OVER");
            }
            if (button2.Bounds.IntersectsWith(button5.Bounds))
            {
                timer1.Stop();
                timer2.Stop();
                button2.Enabled = false;
                MessageBox.Show("GAME OVER");
            }
            //prepreka1
            if (button2.Bounds.IntersectsWith(button8.Bounds))
            {
                timer1.Stop();
                timer2.Stop();
                button2.Enabled = false;
                MessageBox.Show("GAME OVER");
            }
            //prepreka2
            if (button2.Bounds.IntersectsWith(button9.Bounds))
            {
                timer1.Stop();
                timer2.Stop();
                button2.Enabled = false;
                MessageBox.Show("GAME OVER");
            }
            //prepreka3
            if (button2.Bounds.IntersectsWith(button10.Bounds))
            {
                timer1.Stop();
                timer2.Stop();
                button2.Enabled = false;
                MessageBox.Show("GAME OVER");
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            Random x = new Random();
            button7.Left = x.Next(559);
            button7.Top = x.Next(391);
        }
    }
}
